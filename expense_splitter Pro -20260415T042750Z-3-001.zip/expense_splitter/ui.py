import tkinter as tk
from tkinter import ttk, messagebox
from logic import ExpenseManager
from data_manager import save_data, load_data

class App:
    def __init__(self, root):
        self.manager = ExpenseManager()

        root.title("Expense Splitter Pro")

        # UI Style
        style = ttk.Style()
        style.theme_use("clam")

        # Name Entry
        self.name_entry = ttk.Entry(root)
        self.name_entry.grid(row=0, column=0)

        ttk.Button(root, text="Add", command=self.add_person).grid(row=0, column=1)

        self.listbox = tk.Listbox(root)
        self.listbox.grid(row=1, column=0, columnspan=2)

        # Expense Entry
        self.amount_entry = ttk.Entry(root)
        self.amount_entry.grid(row=2, column=0)

        self.payer = tk.StringVar()
        self.dropdown = ttk.Combobox(root, textvariable=self.payer)
        self.dropdown.grid(row=2, column=1)

        ttk.Button(root, text="Add Expense", command=self.add_expense).grid(row=3, column=0)

        ttk.Button(root, text="Calculate", command=self.calculate).grid(row=3, column=1)

        ttk.Button(root, text="Save", command=self.save).grid(row=4, column=0)
        ttk.Button(root, text="Load", command=self.load).grid(row=4, column=1)

        self.output = tk.Text(root, height=10)
        self.output.grid(row=5, column=0, columnspan=2)

    def add_person(self):
        name = self.name_entry.get()
        self.manager.add_person(name)
        self.listbox.insert(tk.END, name)
        self.dropdown["values"] = self.manager.people

    def add_expense(self):
        try:
            amount = float(self.amount_entry.get())
            payer = self.payer.get()
            self.manager.add_expense(payer, amount)
            messagebox.showinfo("Success", "Expense Added")
        except:
            messagebox.showerror("Error", "Invalid input")

    def calculate(self):
        self.output.delete(1.0, tk.END)
        transactions = self.manager.simplify_debts()
        for d, c, amt in transactions:
            self.output.insert(tk.END, f"{d} pays {c}: {amt}\n")

    def save(self):
        save_data("data.json", self.manager.people, self.manager.expenses)

    def load(self):
        people, expenses = load_data("data.json")
        self.manager.people = people
        self.manager.expenses = expenses
        self.listbox.delete(0, tk.END)
        for p in people:
            self.listbox.insert(tk.END, p)
        self.dropdown["values"] = people