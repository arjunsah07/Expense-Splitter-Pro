class ExpenseManager:
    def __init__(self):
        self.people = []
        self.expenses = []

    def add_person(self, name):
        if name not in self.people:
            self.people.append(name)

    def add_expense(self, payer, amount):
        self.expenses.append((payer, amount))

    def calculate_balances(self):
        total = sum(amount for _, amount in self.expenses)
        share = total / len(self.people)

        balances = {p: 0 for p in self.people}

        for payer, amount in self.expenses:
            balances[payer] += amount

        for p in balances:
            balances[p] -= share

        return balances

    def simplify_debts(self):
        balances = self.calculate_balances()

        debtors = [[p, -amt] for p, amt in balances.items() if amt < 0]
        creditors = [[p, amt] for p, amt in balances.items() if amt > 0]

        transactions = []
        i, j = 0, 0

        while i < len(debtors) and j < len(creditors):
            d_name, d_amt = debtors[i]
            c_name, c_amt = creditors[j]

            settled = min(d_amt, c_amt)
            transactions.append((d_name, c_name, round(settled, 2)))

            debtors[i][1] -= settled
            creditors[j][1] -= settled

            if debtors[i][1] == 0:
                i += 1
            if creditors[j][1] == 0:
                j += 1

        return transactions