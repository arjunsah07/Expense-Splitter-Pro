import json

def save_data(filename, people, expenses):
    data = {
        "people": people,
        "expenses": expenses
    }
    with open(filename, "w") as f:
        json.dump(data, f)

def load_data(filename):
    try:
        with open(filename, "r") as f:
            data = json.load(f)
            return data["people"], data["expenses"]
    except:
        return [], []